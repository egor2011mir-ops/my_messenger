import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter/services.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://ivuuxgvjbytjgzheggqr.supabase.co',
    anonKey: 'sb_publishable_j_Z6PHX0a1mv2N5ET4ePQw_NEwZhEnr',
  );
  runApp(const MyApp());
}

class LocalDB {
static List<Map<String, String>> users = [];
static Map<String, String>? currentUser;
static List<Map<String, String>> messages = [];
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  static ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);
  static ValueNotifier<double> fontSizeNotifier = ValueNotifier(16.0);

  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;

    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, currentMode, __) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Messenger',
          theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue), useMaterial3: true),
          darkTheme: ThemeData.dark(useMaterial3: true),
          themeMode: currentMode,
          home: session != null ? const MainTabsScreen() : const AuthScreen(),
        );
      },
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _usernameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _birthdateController = TextEditingController();
  bool _isLoading = false;
  bool _isSignUp = false;

void _submit() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) return;

    setState(() {
      _isLoading = true;
    });

    try {
      if (_isSignUp) {
        // ==================== РЕЖИМ РЕГИСТРАЦИИ ====================
        final authRes = await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
        );

        final String? newUserId = authRes.user?.id;

        if (newUserId != null) {
          await Supabase.instance.client.from('profiles').upsert({
            'id': newUserId,
            'username': _usernameController.text.trim(),
            'phone': _phoneController.text.trim(),
            'birth_date': _birthdateController.text.trim(),
            'full_name': 'Пользователь',
            'avatar_url': 'default',
          });
          
          if (authRes.session != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Регистрация успешна! Входим...')),
            );
            
            if (mounted) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const MainTabsScreen()),
              );
            }
            return;
          }
        }
      } else {
        // ==================== РЕЖИМ ВХОДА (ЛОГИНА) ====================
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
        
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const MainTabsScreen()),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isSignUp ? 'Регистрация' : 'Вход'), backgroundColor: Colors.blue.shade100),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextField(controller: _emailController, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
                const SizedBox(height: 12),
                TextField(controller: _passwordController, decoration: const InputDecoration(labelText: 'Пароль', border: OutlineInputBorder()), obscureText: true),
                if (_isSignUp) ...[
                  const SizedBox(height: 12),
                  TextField(controller: _usernameController, decoration: const InputDecoration(labelText: 'Юзернейм', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(controller: _phoneController, decoration: const InputDecoration(labelText: 'Телефон', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                TextField(
                  controller: _birthdateController,
                  decoration: const InputDecoration(
                    labelText: 'Дата рождения',
                    border: OutlineInputBorder(),
                  ),
                ),
                ],
                const SizedBox(height: 20),
                ElevatedButton(onPressed: _submit, child: Text(_isSignUp ? 'Создать аккаунт' : 'Войти')),
                TextButton(onPressed: () => setState(() => _isSignUp = !_isSignUp), child: Text(_isSignUp ? 'Есть аккаунт? Войти' : 'Нет аккаунта? Создать'))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainTabsScreen extends StatelessWidget {
  const MainTabsScreen({super.key});
  Widget build(BuildContext context) => const MainTabsScreenContent();
}
class MainTabsScreenContent extends StatefulWidget {
  const MainTabsScreenContent({super.key});
  State<MainTabsScreenContent> createState() => _MainTabsScreenState();
}

class _MainTabsScreenState extends State<MainTabsScreenContent> {
  int _currentIndex = 0;
  final _screens = [const ActivechatsScreen(), const SearchScreen(), const SettingsScreen()];
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex, onTap: (idx) => setState(() => _currentIndex = idx),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Чаты'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Поиск'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Настройки'),
        ],
      ),
    );
  }
}

class ActivechatsScreen extends StatelessWidget {
  const ActivechatsScreen({super.key});

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Диалоги'), 
        backgroundColor: Colors.blue.shade50,
      ),
      body: ListView(
        children: [
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.blueAccent,
              child: Icon(Icons.bookmark, color: Colors.white),
            ),
            title: const Text('Избранное', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('Чат с самим собой. Заметки, фото, ссылки...'),
            trailing: const Icon(Icons.chevron_right, color: Colors.grey),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => ChatScreen(chatWith: {'id': Supabase.instance.client.auth.currentUser?.id ?? '', 'full_name': 'Избранное', 'username': 'saved'}),
              ));
            },
          ),
        ],
      ),
    );
  }
}
  
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _searchController = TextEditingController();
  List<dynamic> _foundUsers = [];
  bool _isLoading = false;

void _search() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      setState(() {
        _foundUsers = [];
        _isLoading = false;
      });
      return;
    }

    setState(() {
      _isLoading = true; // Включаем крутилку загрузки
    });

    try {
      // 1. Умная очистка: если ввели @egor2, автоматически отрезаем собачку
      String cleanQuery = query;
      if (cleanQuery.startsWith('@')) {
        cleanQuery = cleanQuery.substring(1);
      }

      final myId = Supabase.instance.client.auth.currentUser?.id;

      // 2. БРОНЕБОЙНЫЙ ЗАПРОС К СЕРВЕРУ SUPABASE
      // Скачиваем список всех профилей, чей username частично или полностью совпадает с вводом
      final response = await Supabase.instance.client
          .from('profiles') // Ищем в официальной таблице профилей Supabase
          .select('id, username, full_name, avatar_url'); // Запрашиваем только нужные карточке данные

      if (mounted) {
        setState(() {
          // Фильтруем список на самом телефоне: ищем буквы без учета регистра и исключаем себя
          _foundUsers = (response as List)
              .where((user) {
                final usernameFromDatabase = (user['username'] ?? '').toString().toLowerCase();
                final searchedUsername = cleanQuery.toLowerCase();
                
                // Исключаем свой собственный аккаунт из выдачи, а чужие профили ищем по совпадению букв
                return user['id'] != myId && usernameFromDatabase.contains(searchedUsername);
              })
              .toList();
          
          _isLoading = false; // Гарантированно выключаем крутилку!
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _foundUsers = [];
          _isLoading = false; // Принудительно гасим загрузку при любом сбое сети
        });
        // Выводим аккуратную плашку с текстом ошибки на экран
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка сети Supabase: $e')),
        );
      }
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Поиск контактов'), backgroundColor: Colors.blue.shade50),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _searchController, decoration: const InputDecoration(hintText: 'Введите username...', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: _search, child: _isLoading ? const CircularProgressIndicator() : const Text('Найти')),
            const SizedBox(height: 20),
            Expanded(
              child: _foundUsers.isEmpty
                  ? const Center(child: Text('Введите данные для поиска', style: TextStyle(color: Colors.grey)))
                  : ListView.builder(
                      itemCount: _foundUsers.length,
                      itemBuilder: (context, index) {
                        final user = _foundUsers[index];
                        return ListTile(
                          leading: CircleAvatar(backgroundImage: NetworkImage(user['avatar_url'] ?? 'https://robohash.org')),
                          title: Text(user['full_name'] ?? 'Пользователь'),
                          subtitle: Text('@${user['username'] ?? 'username'}'),
                          trailing: const Icon(Icons.chat, color: Colors.blue),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(
                              builder: (_) => ChatScreen(chatWith: {
                                'full_name': user['full_name'] ?? 'Чат',
                                'username': user['username'] ?? ''
                              }),
                            ));
                          },
                        );
                      },
                    ),
            )
          ],
        ),
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _nameController = TextEditingController(text: "Егор");
  final _usernameController = TextEditingController(text: "egor_pro");
  final _phoneController = TextEditingController(text: "+7 999 123 45 67");
  final _birthController = TextEditingController(text: "01.01.2005");
  void initState() {
    super.initState();
    _loadMobileSettings();
  }

  void _loadMobileSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final u = Supabase.instance.client.auth.currentUser;
    setState(() {
      // Считываем сохраненный размер шрифта и тему из памяти телефона
      MyApp.fontSizeNotifier.value = prefs.getDouble('fontSize') ?? 16.0;
      MyApp.themeNotifier.value = (prefs.getBool('isDark') ?? false) ? ThemeMode.dark : ThemeMode.light;
      
      // Скачиваем имя, телефон и вашего СОХРАНЕННОГО робота-аватарку с сервера
      if (u != null) {
        _nameController.text = u.userMetadata?['full_name'] ?? 'Егор';
        _usernameController.text = u.userMetadata?['username'] ?? 'username';
        _phoneController.text = u.userMetadata?['phone'] ?? '+7...';
        _birthController.text = u.userMetadata?['birth_date'] ?? '01.01.2005';
        _avatarUrl = u.userMetadata?['avatar_url'] ?? 'https://robohash.org';
      }
    });
  }
  
  bool _isDarkTheme = false;
  bool _notificationsEnabled = true;
  double _fontSize = 16.0;
  String _avatarUrl = "https://placeholder.co"; // Стандартная временная аватарка

void _changeAvatar() async {
    final ImagePicker picker = ImagePicker();
    // Этот метод сам вызывает системное уведомление Android "Разрешить доступ к галерее?"
    final XFile? image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 50);
    
    if (image != null) {
      setState(() {
        _avatarUrl = image.path; // Запоминаем путь к выбранной фотке
      });
    }
  }

void _saveProfileData() async {
    try {
      // Записываем тему и шрифт в вечную память браузера при нажатии галочки
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isDark', MyApp.themeNotifier.value == ThemeMode.dark);
      await prefs.setDouble('fontSize', MyApp.fontSizeNotifier.value);

      // Отправляем измененные вами данные на вечный сервер Supabase
      await Supabase.instance.client.auth.updateUser(UserAttributes(
        data: {
          'full_name': _nameController.text.trim(), 
          'username': _usernameController.text.trim(), 
          'phone': _phoneController.text.trim(), 
          'birth_date': _birthController.text.trim(), 
          'avatar_url': _avatarUrl, 
        },
      ));
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Все настройки сохранены на сервере и в браузере!')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка сохранения: $e')));
    }
  }
  
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Настройки профиля'), backgroundColor: Colors.blue.shade50, actions: [
        IconButton(icon: const Icon(Icons.check, color: Colors.blue), onPressed: _saveProfileData)
      ]),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // БЛОК 1: КРУГЛАЯ АВАТАРКА С КНОПКОЙ СМЕНЫ

          Center(
          child: Stack(
            children: [
              CircleAvatar(
                radius: 55,
                backgroundColor: Colors.grey.shade300,
                backgroundImage: _avatarUrl == 'default' 
    ? null 
    : (_avatarUrl.startsWith('http') 
        ? NetworkImage(_avatarUrl) 
        : FileImage(File(_avatarUrl)) as ImageProvider),
                child: _avatarUrl == 'default' ? const Icon(Icons.person, size: 55, color: Colors.white) : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: CircleAvatar(
                  radius: 18,
                  backgroundColor: Colors.blue,
                  child: IconButton(
                    icon: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                    onPressed: _changeAvatar,
                  ),
                ),
              ),
            ],
          ),
        ),

            const SizedBox(height: 25),
            const Text('ЛИЧНЫЕ ДАННЫЕ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 10),
            TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Имя', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: _usernameController, decoration: const InputDecoration(labelText: 'Имя пользователя (username)', prefixIcon: Icon(Icons.alternate_email), border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: _phoneController, decoration: const InputDecoration(labelText: 'Номер телефона', prefixIcon: Icon(Icons.phone), border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: _birthController, decoration: const InputDecoration(labelText: 'Дата рождения', prefixIcon: Icon(Icons.cake), border: OutlineInputBorder())),
            
            const SizedBox(height: 30),
            const Text('НАСТРОЙКИ ПРИЛОЖЕНИЯ И ЧАТОВ', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 10),
            
          Card(child: Column(children: [
          SwitchListTile(title: const Text('Тёмная тема оформления'), secondary: const Icon(Icons.dark_mode), value: MyApp.themeNotifier.value == ThemeMode.dark, onChanged: (v) { setState(() { MyApp.themeNotifier.value = v ? ThemeMode.dark : ThemeMode.light; }); }),
          ValueListenableBuilder<double>(
            valueListenable: MyApp.fontSizeNotifier,
            builder: (_, size, __) => ListTile(
              leading: const Icon(Icons.text_fields), title: const Text('Размер шрифта в чатах'),
              subtitle: Slider(min: 12.0, max: 24.0, divisions: 6, label: size.round().toString(), value: size, onChanged: (v) => setState(() => MyApp.fontSizeNotifier.value = v)),
            ),
          ),
        ])),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red), title: const Text('Выйти из аккаунта', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
              onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen())),
            ),
          ],
        ),
      ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final Map<String, String> chatWith;
  const ChatScreen({super.key, required this.chatWith});
  State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  bool _isCustomBottomSheetOpen = false; // Открыта ли наша шторка
  bool _isCustomDeleteDialogOpen = false; // Открыто ли наше окно удаления
  bool _isDeleteGroupMode = false; // Удаляем пачку или одно сообщение
  int? _clickedMessageIndex; // Номер сообщения, на которое нажали
  Map<String, dynamic>? _replyingMessage;
  final FocusNode _messageFocusNode = FocusNode();
  bool _showScrollDownButton = false; // По умолчанию кнопка скрыта
  bool _isTextFieldBlocked = false;
  bool _isCustomMenuOpen = false; // Открыто ли наше меню
  int? _clickedMsgIndex; // Номер сообщения, на которое нажали
  bool _isCustomDeleteOpen = false; // Открыто ли наше окно удаления
  bool _isGroupDelete = false; // Режим группового удаления
  final _msg = TextEditingController();
  List<dynamic> _serverMessages = [];
  Set<int> _selectedIndexes = {};
  final ScrollController _scrollController = ScrollController();
  bool _isLoading = true;
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.hasClients) {
        // Вычисляем, сколько пикселей осталось до самого-самого низа чата
        double pixelsFromBottom = _scrollController.position.maxScrollExtent - _scrollController.position.pixels;
        
        // Если пользователь отмотал чат вверх больше чем на 150 пикселей — показываем стрелочку
        if (pixelsFromBottom > 150) {
          if (!_showScrollDownButton) {
            setState(() {
              _showScrollDownButton = true;
            });
          }
        } else {
          // Если пользователь вернулся в самый низ — прячем её обратно
          if (_showScrollDownButton) {
            setState(() {
              _showScrollDownButton = false;
            });
          }
        }
      }
    });
    _loadMessages();
  }

  void _loadMessages() async {
    try {
      final res = await Supabase.instance.client.from('messages').select('*, profiles(username)').order('created_at', ascending: true);
      setState(() {
          final user = Supabase.instance.client.auth.currentUser;
          final myId = user?.id ?? '';
          _serverMessages = (res as List<dynamic>).where((msg) {
            final hiddenUsers = (msg['hidden_by'] ?? '').toString().split(',');
            return !hiddenUsers.contains(myId);
          }).toList();
          _isLoading = false;
        });
    } catch (e) { setState(() => _isLoading = false); }
    // УМНОЕ И МГНОВЕННОЕ ОТКРЫТИЕ ДИАЛОГА ПРИ ВХОДЕ
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          int firstUnreadIndex = -1;
          
          
          // Бежим по списку и ищем самое первое непрочитанное сообщение от собеседника
          for (int i = 0; i < _serverMessages.length; i++) {
            if (_serverMessages[i]['sender_id'] != Supabase.instance.client.auth.currentUser?.id) {
              firstUnreadIndex = i;
              break; // Нашли полоску новых сообщений, останавливаем поиск
            }
          }

          if (firstUnreadIndex != -1) {
            // ЕСТЬ НОВЫЕ СООБЩЕНИЯ: мгновенно открываем чат ровно на нашей разделительной полоске
            double targetPosition = firstUnreadIndex * 85.0; // 85 пикселей - средняя высота облачка с временем
            if (targetPosition > _scrollController.position.maxScrollExtent) {
              targetPosition = _scrollController.position.maxScrollExtent;
            }
            _scrollController.jumpTo(targetPosition); // jumpTo делает прыжок МГНОВЕННО
          } else {
            // ЧАТ ЧИСТ: мгновенно открываем самый конец длинной переписки
            _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
          }
        }
      });
  }
  void _scrollToBottom() async {
    if (_scrollController.hasClients) {
      String _getDisplayDate(String? createdAtString) {
    if (createdAtString == null) return '';
    try {
      DateTime msgDate = DateTime.parse(createdAtString).toLocal();
      DateTime now = DateTime.now();
      
      DateTime today = DateTime(now.year, now.month, now.day);
      DateTime yesterday = today.subtract(const Duration(days: 1));
      DateTime msgDay = DateTime(msgDate.year, msgDate.month, msgDate.day);

      if (msgDay == today) return 'Сегодня';
      if (msgDay == yesterday) return 'Вчера';

      List<String> months = [
        'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
        'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
      ];
      
      return "${msgDate.day} ${months[msgDate.month - 1]} ${msgDate.year}";
    } catch (e) {
      return '';
    }
  }
      // 1. Плавно докручиваем ленту до самого конца
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );

      // 2. Так как мы в самом низу, помечаем входящие сообщения прочитанными на сервере
      final myId = Supabase.instance.client.auth.currentUser?.id;
      try {
        await Supabase.instance.client
            .from('messages')
            .update({'is_read': true})
            .eq('sender_id', widget.chatWith)
            .eq('receiver_id', myId ??'')
            .eq('is_read', false);
      } catch (e) {}
    }
  }
void _send() async {
    final text = _msg.text.trim();
    if (text.isEmpty) return;
    _msg.clear();
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) return;
      // Отправляем сообщение в созданную нами таблицу messages
      if (_editingMessageId != null) {
        // РЕЖИМ РЕДАКТИРОВАНИЯ: обновляем текст старого сообщения по его ID!
        await Supabase.instance.client
            .from('messages')
            .update({'text': text})
            .eq('id', _editingMessageId!);
        _editingMessageId = null; // Сбрасываем режим редактирования после сохранения
      } else {
        setState(() {
  _replyingMessage = null;
});
        // ОБЫЧНЫЙ РЕЖИМ: создаем новое сообщение
        await Supabase.instance.client.from('messages').insert({
          'text': text,
          'sender_id': user.id,
          'receiver_id': (widget.chatWith == 'Избранное' || widget.chatWith == null) ? user.id : widget.chatWith,
          'reply_to_id': _replyingMessage?['id'],
          'is_read': widget.chatWith == 'Избранное',
        });
      }
      _loadMessages();
      Future.delayed(const Duration(milliseconds: 100), () {
      _scrollToBottom();
    });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка отправки: $e')));
    }
  }
  int? _editingMessageId;
  void _safePop(BuildContext context) {
    setState(() {
      _isTextFieldBlocked = true; // 💥 Намертво замораживаем поле ввода для Android!
    });
    
    WidgetsBinding.instance.focusManager.primaryFocus?.unfocus();
    _messageFocusNode.unfocus();
    
    Future.microtask(() {
      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
      // Размораживаем поле ввода обратно чуть позже, когда анимация окна полностью затихнет
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted) {
          setState(() {
            _isTextFieldBlocked = false;
          });
        }
      });
    });
  }

  void _showDeleteDialog({required bool isGroup, int? index}) {
    // ЖЕСТКИЙ ЗАМОК №1: Гарантированно усыпляем клавиатуру в самую первую миллисекунду вызова окна!
    FocusScope.of(context).unfocus(); 

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        final currentUser = Supabase.instance.client.auth.currentUser;
        final myId = currentUser?.id ?? '';

        return AlertDialog(
          title: const Text('Удалить?'),
          content: Text(isGroup 
              ? 'Удалить выбранные сообщения для себя или для всех?' 
              : 'Вы хотите удалить это сообщение только для себя или для всех участников?'),
          actions: [
            TextButton(
              child: const Text('Только у меня', style: TextStyle(color: Colors.black)),
              onPressed: () async {
                _safePop(dialogContext);
                FocusScope.of(context).unfocus(); // ЖЕСТКИЙ ЗАМОК №2: Гарантированно спим при закрытии окна
                try {
                  if (isGroup) {
                    for (var idx in _selectedIndexes) {
                      final currentHidden = _serverMessages[idx]['hidden_by'] ?? '';
                      final updatedHidden = currentHidden.isEmpty ? myId : '$currentHidden,$myId';
                      await Supabase.instance.client.from('messages').update({'hidden_by': updatedHidden}).eq('id', _serverMessages[idx]['id']);
                    }
                  } else if (index != null) {
                    final currentHidden = _serverMessages[index]['hidden_by'] ?? '';
                    final updatedHidden = currentHidden.isEmpty ? myId : '$currentHidden,$myId';
                    await Supabase.instance.client.from('messages').update({'hidden_by': updatedHidden}).eq('id', _serverMessages[index]['id']);
                  }
                  setState(() => _selectedIndexes.clear());
                  _loadMessages();
                } catch (e) {}
              },
            ),
            TextButton(
              child: const Text('Удалить у всех', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
              onPressed: () async {
                _safePop(dialogContext);
                FocusScope.of(context).unfocus(); // ЖЕСТКИЙ ЗАМОК №3: Гарантированно спим при удалении у всех
                try {
                  if (isGroup) {
                    final idsToDelete = _selectedIndexes.map((idx) => _serverMessages[idx]['id']).toList();
                    await Supabase.instance.client.from('messages').delete().inFilter('id', idsToDelete);
                  } else if (index != null) {
                    await Supabase.instance.client.from('messages').delete().eq('id', _serverMessages[index]['id']);
                  }
                  setState(() => _selectedIndexes.clear());
                  _loadMessages();
                } catch (e) {}
              },
            ),
          ],
        );
      },
    );
  }
  void _showForwardChatsDialog(BuildContext context, List<dynamic> messages) async {
    final currentUser = Supabase.instance.client.auth.currentUser;
    if (currentUser == null) return;

    // Быстро запрашиваем список всех пользователей из таблицы profiles
    final List<dynamic> allUsers = await Supabase.instance.client
        .from('profiles')
        .select()
        .not('id', 'eq', currentUser.id); // Исключаем себя

    if (!context.mounted) return;

    // Открываем красивое полноэкранное окно (как в Telegram)
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (bottomSheetContext) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.85,
          padding: const EdgeInsets.only(top: 16, left: 16, right: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Переслать сообщение',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(bottomSheetContext),
                  ),
                ],
              ),
              const Divider(),
              Expanded(
                child: ListView.builder(
                  itemCount: allUsers.length,
                  itemBuilder: (ctx, index) {
                    final user = allUsers[index];
                    final String targetUserId = user['id'];
                    final String targetUsername = user['username'] ?? 'Пользователь';

                    return ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Colors.blueAccent,
                        child: Icon(Icons.person, color: Colors.white),
                      ),
                      title: Text(targetUsername),
                      onTap: () async {
                        Navigator.pop(bottomSheetContext);

                        for (var msg in messages) {
                          final String originalText = msg['text'] ?? '';
                          final String rawSenderName = msg['profiles']?['username'] ?? 'Пользователь';
                          final String formattedForwardName = '@$rawSenderName'; // Добавляем собачку!

                          // Отправляем СМС в таблицу messages нового чата
                          await Supabase.instance.client.from('messages').insert({
                            'text': originalText,
                            'sender_id': currentUser.id,
                            'receiver_id': targetUserId,
                            'forwarded_from_username': formattedForwardName,
                          });
                        }

                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Сообщения успешно пересланы!')),
                          );
                        }
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      floatingActionButton: _showScrollDownButton 
          ? Padding(
              padding: const EdgeInsets.only(bottom: 90), // Поднимает стрелочку над строкой ввода сообщения
              child: FloatingActionButton(
                mini: true, // Маленькая и аккуратная, как в Telegram
                backgroundColor: Colors.white.withOpacity(0.9),
                child: const Icon(Icons.arrow_downward, color: Colors.blue),
                onPressed: () {
                  Supabase.instance.client.from('messages').update({'is_read': true}).eq('sender_id', (widget.chatWith ?? '').toString()).eq('receiver_id', Supabase.instance.client.auth.currentUser?.id ?? '').eq('is_read', false).then((_) => _loadMessages());
                  
                  if (_scrollController.hasClients) {
                    _scrollController.animateTo(
                      _scrollController.position.maxScrollExtent,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                    );
                  }
                },
              ),
            )
          : null,
      appBar: AppBar(
          title: Text(_selectedIndexes.isNotEmpty 
              ? 'Выбрано: ${_selectedIndexes.length}' 
              : (widget.chatWith['full_name'] ?? "var")),
          backgroundColor: Colors.blue.shade50,
          leading: _selectedIndexes.isNotEmpty 
              ? IconButton(
                  icon: const Icon(Icons.close), 
                  onPressed: () => setState(() => _selectedIndexes.clear())
                )
              : null,
          actions: _selectedIndexes.isNotEmpty
              ? [
                  IconButton(
                    icon: const Icon(Icons.copy),
                    onPressed: () {
                      final buffer = _selectedIndexes
                          .map((i) => _serverMessages[i]['text'] ?? '')
                          .join('\n');
                      Clipboard.setData(ClipboardData(text: buffer));
                      setState(() => _selectedIndexes.clear());
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Сообщения скопированы!')),
                      );
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _showDeleteDialog(isGroup: true),
                  ),
                  IconButton(
              icon: const Icon(Icons.forward, color: Colors.blue),
              onPressed: () {
                // Собираем все выделенные сообщения в список
                final messagesToForward = _selectedIndexes.map((idx) => _serverMessages[idx]).toList();
                // Сбрасываем выделение на экране, чтобы чат вернулся в обычный режим
                setState(() {
                  _selectedIndexes.clear();
                });
                // Открываем окно со списком всех чатов для пересылки!
                _showForwardChatsDialog(context, messagesToForward);
              },
            ),
                ]
              : null,
        ),
      body: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            _messageFocusNode.unfocus();
          },
          child: Column(
            children: [
          Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  controller: _scrollController,
                  itemCount: _serverMessages.length,
                  itemBuilder: (ctx, i) {
                    // Умная проверка: нужно ли нарисовать линию "Новые сообщения"
                    bool showNewMessagesLine = false;
                    // Умная проверка: нужно ли показать овал с датой дня
                    bool showDateDivider = false;
                    String dateText = _serverMessages[i]['created_at']?.toString().split('T')[0] ?? '';
                    
                    if (i == 0) {
                      // Перед самым первым сообщением в чате дату выводим всегда
                      showDateDivider = true;
                    } else {
                      // Сравниваем день текущего сообщения с предыдущим
                      String prevDateText = _serverMessages[i - 1]['created_at']?.toString().split('T')[0] ?? '';
                      if (dateText != prevDateText) {
                        showDateDivider = true;
                      }
                    }
                    final myId = Supabase.instance.client.auth.currentUser?.id;
                    
                    // Если сообщение прислали НЕ вы и оно ещё не прочитано
                    if (_serverMessages[i]['sender_id'] != myId && _serverMessages[i]['is_read'] == false) {
                      // И если это вообще первое сообщение в списке ИЛИ предыдущее перед ним было прочитано
                      if (i == 0 || _serverMessages[i - 1]['is_read'] == true) {
                        showNewMessagesLine = true;
                      }
                    }
                    final isMe = _serverMessages[i]['sender_id'] == Supabase.instance.client.auth.currentUser?.id;

                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_editingMessageId != null)
              Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, top: 8),
                  child: IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () {
                      setState(() {
                        _editingMessageId = null; // Отменяем режим изменения
                        _msg.clear(); // Очищаем поле ввода на клавиатуре
                      });
                      Navigator.pop(context); // Закрываем это всплывающее окошко
                    },
                  ),
                ),
              ),
                        if (showDateDivider && dateText.isNotEmpty)
                          Center(
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 16),
                              padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.08), // Идеальный полупрозрачный Telegram-овал
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                // Превращаем формат "2026-07-05" в красивый вид "05-07-2026"
                                dateText.contains(',') ? dateText.replaceAll('[', '').replaceAll(']', '') : dateText.split('-').reversed.join('.'),
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 11,
                                ),
                              ),
                            ),
                          ),
                        if (showNewMessagesLine)
                          Container(
                            margin: const EdgeInsets.symmetric(vertical: 12),
                            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
                            decoration: BoxDecoration(
                              color: Colors.blue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              'Новые сообщения',
                              style: TextStyle(
                                color: Colors.blue, 
                                fontWeight: FontWeight.bold, 
                                fontSize: 12,
                              ),
                            ),
                          ),
                    GestureDetector(
                      onLongPress: () {
                        FocusScope.of(context).unfocus(); // Намертво гасим клавиатуру при зажатии
                        setState(() {
                          if (_selectedIndexes.contains(i)) {
                            _selectedIndexes.remove(i); // Убираем бирюзовую галочку
                          } else {
                            _selectedIndexes.add(i); // Ставим бирюзовую галочку
                          }
                        });
                      },
                      // --- 1. ОБЫЧНОЕ НАЖАТИЕ (Шторка Telegram) ---
                      onTap: () {
                        final currentMessage = _serverMessages[i];
                        final messageId = currentMessage['id'];
                        final messageText = currentMessage['text'] ?? '';

                        if (_selectedIndexes.isNotEmpty) {
                          FocusScope.of(context).unfocus();
                          setState(() {
                            if (_selectedIndexes.contains(i)) {
                              _selectedIndexes.remove(i);
                            } else {
                              _selectedIndexes.add(i);
                            }
                          });
                          return;
                        }

                        FocusScope.of(context).unfocus();
                        showModalBottomSheet(
                          context: context,
                          builder: (context) {
                            return Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context).scaffoldBackgroundColor,
                                borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                              ),
                              padding: const EdgeInsets.only(top: 16, left: 16, right: 16, bottom: 40), // Выталкивает кнопку "Удалить" из-под системных кнопок телефона!
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: ['👍', '🔥', '❤️', '😂'].map((emoji) {
                                      return IconButton(
                                        icon: Text(emoji, style: const TextStyle(fontSize: 24)),
                                        onPressed: () async {
                                          _safePop(context);
                                          try {
                                            await Supabase.instance.client
                                                .from('messages')
                                                .update({'reaction': emoji})
                                                .eq('id', messageId);
                                            _loadMessages();
                                          } catch (e) {}
                                        },
                                      );
                                    }).toList(),
                                  ),
                                  const Divider(),
                                  ListTile(
                                    leading: const Icon(Icons.copy, color: Colors.blue),
                                    title: const Text('Скопировать текст'),
                                    onTap: () {
                                      _safePop(context);
                                      Clipboard.setData(ClipboardData(text: messageText));
                                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Текст скопирован!')));
                                    },
                                  ),
                                  ListTile(
                                    leading: const Icon(Icons.edit, color: Colors.orange),
                                    title: const Text('Изменить сообщение'),
                                    onTap: () {
                                      _safePop(context);
                                      setState(() {
                                        _msg.text = messageText;
                                        _editingMessageId = messageId;
                                      });
                                    },
                                  ),
                                  ListTile(
                                    leading: const Icon(Icons.delete, color: Colors.red),
                                    title: const Text('Удалить', style: TextStyle(color: Colors.red)),
                                    onTap: () {
                                    Navigator.pop(context); // Мгновенно закрываем строго шторку
                                    _showDeleteDialog(isGroup: false, index: i); // Спокойно открываем окно удаления
                                  },
                                  ),
                                  ListTile(
              leading: const Icon(Icons.reply, color: Colors.blue),
              title: const Text('Ответить', style: TextStyle(color: Colors.blue)),
              onTap: () {
                setState(() {
                  _replyingMessage = _serverMessages[i]; // Запоминаем СМС в память для ответа!
                });
                Navigator.pop(context); // Мгновенно закрываем шторку меню
              },
            ),
                                ],
                              ),
                            );
                          },
                        );
                      },
                      
          child: Dismissible(
            key: Key(_serverMessages[i]['id'].toString()),
          direction: _serverMessages[i]['sender_id'] == Supabase.instance.client.auth.currentUser?.id
              ? DismissDirection.startToEnd // Свои СМС свайпаем вправо
              : DismissDirection.endToStart, // Чужие СМС свайпаем влево
          confirmDismiss: (direction) async {
            setState(() {
              _replyingMessage = _serverMessages[i]; // Запоминаем сообщение для ответа!
            });
            return false; // Отпружинивает назад, как в Telegram!
          },
          background: Container(
            alignment: _serverMessages[i]['sender_id'] == Supabase.instance.client.auth.currentUser?.id
                ? Alignment.centerLeft
                : Alignment.centerRight,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            color: Colors.transparent,
            child: const Icon(Icons.reply, color: Colors.blue, size: 24),
          ),
            child: Align(
                            alignment: Alignment.centerRight,
                            child: Container(
                              margin: const EdgeInsets.all(6),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _selectedIndexes.contains(i) ? Colors.teal.shade200 : Colors.blue.shade200,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: ValueListenableBuilder<double>(
                            valueListenable: MyApp.fontSizeNotifier,
                            builder: (context, size, _) {
                              final isSaved = _serverMessages[i]['sender_id'] == _serverMessages[i]['receiver_id'] || widget.chatWith == 'Избранное';
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (_serverMessages[i]['forwarded_from_username'] != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        'Источник: ${_serverMessages[i]['forwarded_from_username']}',
                        style: const TextStyle(
                          fontSize: 11,
                          color: Colors.blue,
                          fontWeight: FontWeight.w500,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                                  Text(
                                    _serverMessages[i]['text'] ?? '', 
                                    style: TextStyle(fontSize: size),
                                  ),
                                  if (_serverMessages[i]['is_edited'] == true)
              const Padding(
                padding: EdgeInsets.only(top: 2, left: 4),
                child: Text(
                  'изменено',
                  style: TextStyle(
                    fontSize: 10, 
                    color: Colors.grey, 
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
                                  if (_serverMessages[i]['reaction'] != null && _serverMessages[i]['reaction'].toString().isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        _serverMessages[i]['reaction'],
                                        style: const TextStyle(fontSize: 16),
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          _serverMessages[i]['created_at'] != null
                                              ? "${DateTime.parse(_serverMessages[i]['created_at'].toString()).toLocal().hour.toString().padLeft(2, '0')}:${DateTime.parse(_serverMessages[i]['created_at'].toString()).toLocal().minute.toString().padLeft(2, '0')}"
                                              : '',
                                          style: TextStyle(fontSize: size * 0.7, color: Colors.grey.shade600),
                                        ),
                                        if (isMe) ...[
                                          const SizedBox(width: 4),
                                          Text(
                                          (_serverMessages[i]['sender_id'] == _serverMessages[i]['receiver_id'] || _serverMessages[i]['receiver_id'] == null || _serverMessages[i]['is_read'] == true) ? '✓✓' : '✓',
                                          style: TextStyle(
                                            fontSize: size * 0.8,
                                            fontWeight: FontWeight.bold,
                                            color: (_serverMessages[i]['sender_id'] == _serverMessages[i]['receiver_id'] || _serverMessages[i]['receiver_id'] == null || _serverMessages[i]['is_read'] == true) ? Colors.teal : Colors.grey.shade600,
                                          ),
                                        ),
                                        ],
                                      ],
                                    ),
                                ],
                              );
                            },
                          ),
                            ),
                          ),
          ),
                      ),
                    ],
                  );
                    },
                  ),
          ),
          Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom > 0 
                ? MediaQuery.of(context).viewInsets.bottom 
                : 50, 
            left: 10, 
            right: 10,
          ),
            child: Row(
              children: [
                if (_replyingMessage != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                color: Colors.grey.shade100,
                child: Row(
                  children: [
                    const Icon(Icons.reply, color: Colors.blue, size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(
                            'Ответ на сообщение',
                            style: TextStyle(
                              color: Colors.blue,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _replyingMessage!['text'] ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.black54,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _replyingMessage = null; // Закрываем режим ответа по крестику!
                        });
                      },
                      child: const Icon(Icons.close, color: Colors.grey, size: 20),
                    ),
                  ],
                ),
              ),
                Expanded(
                  child: TextField(
                    controller: _msg,
                    readOnly: _isTextFieldBlocked,
                    decoration: const InputDecoration(hintText: 'Сообщение...', border: OutlineInputBorder()),
                  ),
                ),
                IconButton(icon: const Icon(Icons.send, color: Colors.blue), onPressed: _send),
              ],
            ),
          )
        ],
      ),
    ));
  }
}